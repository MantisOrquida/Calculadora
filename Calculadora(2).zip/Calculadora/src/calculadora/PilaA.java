/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author 165473, 187541,  183057, 168228
 */
public class PilaA <T> implements PilaADT<T>{
    private T[] datos;
    private int tope;
    private int MAX=50;
    
    public PilaA(){
        datos=(T[]) new Object[MAX];
        tope=-1;
    }
    
    public boolean isEmpty(){
        return tope==-1;
    }
    
    
    
    public void push(T nuevo){
        if(tope+1==datos.length)
            expande();
        tope++;
        datos[tope]=nuevo;
    }
    
    private void expande(){
        T[]grande=(T[]) new Object[datos.length*3];
        for(int i=0;i<=tope;i++)
            grande[i]=datos[i];
        datos=grande;
    }
    
    
    
    public T pop(){
        if(isEmpty())
            throw new ExceptionVacia("Error");
        T resultado=datos[tope];
        datos[tope]=null;
        tope--;
        return resultado;
    }
    
    
    public T peek(){
        if(isEmpty())
            throw new ExceptionVacia("Error");
        return datos[tope];
    }

    
    
    
    
}
