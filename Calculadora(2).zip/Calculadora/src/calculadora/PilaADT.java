/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author 165473, 187541,  183057, 168228
 */
public interface PilaADT <T> {
    public void push (T dato);
    public T pop();
    public boolean isEmpty();
    public T peek();
      
    
}
