/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author 165473, 187541,  183057, 168228
 */
public class ExceptionVacia extends RuntimeException{
    public ExceptionVacia(String mensaje){
        super(mensaje);
    }
    
}
