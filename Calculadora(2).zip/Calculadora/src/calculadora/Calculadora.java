/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author 165473, 187541,  183057, 168228
 */
public class Calculadora {
    
// Métodos auxiliares.
    
    


/**
 * Verifica si un caracter es o no un signo dígito.
 * @param op Caracter.
 * @return <ul>
 * <li>true: es dígito.</li>
 * <li>false: no es dígito.</li>
 * </ul> 

 */ 
    private static boolean esDígito(char op) {
        return op == '0' || op == '1' || op == '2' || op == '3' || op == '4' || op == '5' || op == '6' || op == '7' || op == '8' || op == '9';
    }
/**
 *  <pre> 
 *  Recibe una pila y la invierte.
 *  </pre>
 * @param invertir PilaADT<T>.
 * @return La pila al revés.
 */ 
    public static <T> PilaADT<T> invierte(PilaA<T> invertir) {
        PilaADT<T> res = new PilaA();
        while (!invertir.isEmpty()) {
            res.push(invertir.pop());
        }
        return res;
    }
/**
 *  <pre> 
 * Convierte una expresión a una pila, que se utilizará como infijo, 
 * de números (double), paréntesis y multiplicaciones (char).
 *  </pre>
 * @param op Expresión matemática.
 * @see esDígito
 * * @see esSigno 
 * @return La pila infijo.
 */ 

    public static PilaA<Object> PasarAPila(String op) {
        String auxiliar = "";
        PilaA<Object> p = new PilaA();

        for (int i = op.length() - 1; i > -1; i--) {
            if (esSigno(op.charAt(i)) || op.charAt(i) == '(' || op.charAt(i) == ')') {
                p.push(op.charAt(i));
            } else {
                while (i > -1 && (esDígito(op.charAt(i)) || op.charAt(i) == '.')) {
                    auxiliar = op.charAt(i) + auxiliar;
                    i--;
                }
                i++;
                p.push(Double.parseDouble(auxiliar));
                auxiliar = "";
            }
        }
        return p;

    }
/**
 *  <pre> 
 * Recibe un signo aritmético e indica su jerarquía. 
 *  </pre>
 * @param op Signo aritmético.
 * @return Prioridad (como entero).
 */ 
    private static int Prioridad(char s) {
        int r;
        switch (s) {
            case '-':
                r = 1;
                break;
            case '+':
                r = 1;
                break;
            case '/':
                r = 2;
                break;
            case '*':
                r = 2;
                break;
            default:
                r = 0;
        }
        return r;
    }
/**
 * Verifica si un caracter es o no un signo aritmético.
 * @param op Caracter.
 * @return <ul>
 * <li>true: es signo aritmético.</li>
 * <li>false: no es signo aritmético.</li>
 * </ul> 

 */ 
    private static boolean esSigno(char s) {
        boolean res = false;
        if (s == '+' || s == '-' || s == '*' || s == '/') {
            res = true;
        }
        return res;

    }
/**
 *  <pre> 
 * Imprime una pila.
 *  </pre>
 * @param pilita pila.
 * @return Cadena de caracteres (los elementos de la pila).
 */ 
    public static <Object> String ImprimePila(PilaA<Object> pilita) {
        Object a;
        StringBuilder linea = new StringBuilder();
        PilaA<Object> mane = new PilaA();
        while (!pilita.isEmpty()) {
            a = pilita.pop();
            mane.push(a);
            linea.append(String.format("%s\n", a));
        }
        while (!mane.isEmpty()) {
            pilita.push(mane.pop());

        }

        return linea.toString();
    }
    
    
    /**
 *  <pre> 
 * Llama a los métodos que validan si la expresión inicial es correcta o no.
 *  </pre>
 * @param op Expresión matemática.
 * @see <pre>
 * OperacionesSolas, validacionPuntosDecimal, validacionParentesisVacios,
 * RevisorParentesis y signoYParéntesis.
 *  </pre>
 * @return <ul>
 * <li>true: operación válida.</li>
 * <li>false: operación inválida.</li>
 * </ul> 
 */ 
    
     public static boolean Validar(String op) {
            return OperacionesSolas(op) && validacionPuntosDecimal(op)
                    && validacionParentesisVacios(op) && RevisorParentesis(op)
                    && signoYParéntesis(op);
        }

     
 /**
 * Valida que no haya paréntesis vacíos.
 * @param op Expresión matemática.
 * @return <ul>
 * <li>true: no hay paréntesis vacíos.</li>
 * <li>false: hay paréntesis vacíos.</li>
 * </ul> 

 */ 
    private static boolean validacionParentesisVacios(String op) {
        boolean res = true;
        if (op.length() > 1) {
            for (int i = 0; i < op.length() - 1; i++) {
                if (op.charAt(i) == '(' && op.charAt(i + 1) == ')') {
                    res = false;
                }
            }
        }
        return res;
    }

/**
 * Valida que los paréntesis estén bien escritos.
 * @param op Expresión matemática.
 * @return <ul>
 * <li>true: están bien.</li>
 * <li>false: no están bien.</li>
 * </ul> 
 */ 
    private static boolean RevisorParentesis(String op) {
        PilaA<Character> p = new PilaA();
        int i = 0;
        boolean aux = true;
        while (i < op.length() && aux) {
            if (op.charAt(i) == '(') {
                p.push(op.charAt(i));
            } else if (op.charAt(i) == ')') {
                try {
                    p.pop();
                } catch (ExceptionVacia e) {
                    aux = false;
                }

            }
            i++;
        }

        return aux && p.isEmpty();
    }

    /**
 *  <pre> 
 * Verifica que no haya una operación antes de un paréntesis 
 * de cierre o al final de la expresión que no haya multiplicación 
 * o división al principio de la expresión o después de un paréntesis 
 * de apertura.
 *  </pre>
 * @param op Expresión matemática.
 * @see esSigno 
 * @return true si al final de la expresión no hay un signo o justo
 * antes del cierre de paréntesis, no haya un signo.
 */ 
    private static boolean signoYParéntesis(String op) {
        boolean resp = true;
        if (esSigno(op.charAt(op.length() - 1)) || op.charAt(0) == '*' || op.charAt(0) == '/') {
            resp = false;
        } else if (op.length() > 1) { //no 3
            int i = 0;
            while (i < op.length() - 1 && resp) {
                if (esSigno(op.charAt(i)) && op.charAt(i + 1) == ')') {
                    resp = false;
                } else if (op.charAt(i) == '(' && esSigno(op.charAt(i + 1))) {
                    resp = false;
                }
                i++;
            }
        }
        return resp;
    }

    
    /**
 *  <pre> 
 * Valida dos signos de operación no estén juntos. 
 *  </pre>
 * @param op Expresión matemática.
 * @see esSigno 
 * @return true si no hay dos signos de operaciones juntas.
 */ 
    private static boolean OperacionesSolas(String op) {
        boolean resp = true;
        for (int i = 0; i < op.length() - 1; i++) {
            if (esSigno(op.charAt(i))) {
                if (esSigno(op.charAt(i + 1))) {
                    resp = false;
                }
            }
        }
        return resp;
    }

/**
 *  <pre> 
 * Valida el que sólo haya un punto decimal en el número. 
 *  </pre>
 * @param op Expresión matemática.
 * @see esSigno 
 * @return true si sólo hay un punto por número.
 */ 
    private static boolean validacionPuntosDecimal(String op) {
        int i;
        int cont = 0;
        boolean res = true;
        for (i = 0; i < op.length(); i++) {
            if (esSigno(op.charAt(i)) || op.charAt(i) == '(' || op.charAt(i) == ')' && i < op.length() && res) {
                cont = 0;
            }
            if (op.charAt(i) == '.') {
                cont++;
            }
            if (cont > 1) {
                res = false;
            }
            else if (op.charAt(i) == '.' && op.charAt(i + 1) == '(') {
                res = false;
            }
            else if (op.charAt(i) == '.' && op.charAt(i + 1) == ')') {
                res = false;
            }
            else if (op.charAt(i) == '.' && !Character.isDigit(op.charAt(i + 1))) {
                res = false;
            }
        }
        return res;
    }
    /**
 *  <pre> 
 * Convierte al posfijo en la respuesta final.
 * Nota: hay dos casos: si no hay división entre cero se arroja el resultado;
 * si la hay se lanza excepción.
 *  </pre>
 * @param pila El posfijo.
 * @return La respuesta final.
 */ 
    public static double evalúa(PilaADT<Object> pila) throws Exception {
        PilaADT<Object> núms = new PilaA();
        char b;
        while (!pila.isEmpty()) {
            if ((pila.peek() instanceof Double)) {
                núms.push(pila.pop());

            } else {
                b = (Character) pila.pop();
                switch (b) {
                    case '-':
                        núms.push(-((double) núms.pop()) + ((double) núms.pop()));
                        break;
                    case '+':
                        núms.push(((double) núms.pop()) + ((double) núms.pop()));
                        break;
                    case '*':
                        núms.push(((double) núms.pop()) * ((double) núms.pop()));
                        break;
                    case '/':
                        if ((double) núms.peek() != 0) {
                            double c = (double) núms.pop();
                            double d = (double) núms.pop();
                            núms.push(d / c);
                           
                        break;
                        } else {
                            throw new Exception("No es válido dividir entre cero.");
                        }
                }
            }

        }

        return (double) núms.peek();
    }
/**
 *  <pre> 
 * Convierte al infijo en posfijo.
 *  </pre>
 * @param pila Infijo.
 * @see Prioridad
 * @return Posfijo.
 */ 
    public static PilaA<Object> ShuntingYard(PilaA<Object> pila) {
        PilaA<Object> resultado = new PilaA(), aux = new PilaA();
        while (!pila.isEmpty()) {
            if (pila.peek() instanceof Double) {
                resultado.push(pila.pop());
            } else if (((char) pila.peek()) == '(') {
                aux.push(pila.pop());
            } else if (((char) pila.peek()) == ')') {
                while (!((char) aux.peek() == '(')) {
                    resultado.push(aux.pop());
                }
                pila.pop();
                aux.pop();
            } else {
                while (!aux.isEmpty() && !(aux.peek() instanceof Double)
                        && Prioridad((char) aux.peek()) >= Prioridad((char) pila.peek())) {
                    resultado.push(aux.pop());
                }
                aux.push(pila.pop());
            }

        }
        while (!aux.isEmpty()) {
            resultado.push(aux.pop());
        }

        return resultado;
    }

   

/**
 *  <pre> 
 * Corrige el formato del texto.
 *  </pre>
 * @param op Expresión matemática.
 * @see MásyMenos 
 * @see paréntesisMultiplica.
 * @return Expresión matemática lista para ser usada en pilas.
 */ 
    public static String Formato(String op) {
        return MásyMenos(paréntesisMultiplica(op));
    }

/**
 *  <pre> 
 * Inserta un signo de multiplicación si los paréntesis están 
 *escritos de manera que se deban interpretar como multiplicación.
 *Agrega ceros en caso de que el signo de suma o resta inicie 
 *  </pre>
 * @param op Expresión matemática.
 * @see esSigno esDígito
 * @return Expresión con un signo de multiplicar.
 */     private static String paréntesisMultiplica(String op) {
        StringBuilder sb = new StringBuilder(op);
        if (op.length() > 3) {
            for (int i = 0; i < sb.length() - 1; i++) {
                if (sb.charAt(i) == ')' && sb.charAt(i + 1) == '(') {
                    sb.insert(i + 1, '*');
                } else if (sb.charAt(i) == ')' && esDígito(sb.charAt(i + 1))) {
                    sb.insert(i + 1, '*');
                } else if (esDígito(sb.charAt(i)) && sb.charAt(i + 1) == '(') {
                    sb.insert(i + 1, '*');
                }
            }
        }
        return sb.toString();
    }

    
/**
 *  <pre> 
 * Agrega ceros en caso de que el signo de suma o resta inicie 
 * la expresión o esté después de un paréntesis, para facilitar
 * las operaciones en posfijo.
 *  </pre>
 * @param op Expresión matemática.
  * @return Expresión con ceros a la izquierda.
 */ 
    private static String MásyMenos(String op) {
        StringBuilder sb = new StringBuilder();
        sb.append(op);
        if (sb.length() > 3) {
            for (int i = 0; i < sb.length() - 2; i++) {
                if ((sb.charAt(i + 1) == '+' || sb.charAt(i + 1) == '-') && sb.charAt(i) == '(') {
                    sb.insert(i + 1, '0');
                }
            }
        }
        if (sb.charAt(0) == '+' || sb.charAt(0) == '-') {
            sb.insert(0, '0');
        }
        return sb.toString();
    }

    

    
}
